# Yamanoha Site Mirror (Python)

This folder contains a small Python crawler that mirrors **https://yamanoha.official.jp/** into a local directory.

## Setup
- Create/activate a virtual environment if you like.
- Install deps:
  ```bash
  python -m pip install -r requirements.txt
  ```

## Run
```bash
python mirror_yamanoha.py --output mirror_output
```

Options:
- `--start-url` to change the root URL (default: `https://yamanoha.official.jp/`).
- `--max-pages` to limit how many HTML pages to crawl (default: 20).
- `--timeout` to control HTTP timeout seconds (default: 15).

The script downloads HTML + common assets (css/js/images/fonts) and rewrites internal links to point to the local copies. Serve the folder with:
```bash
python -m http.server 8000 --directory mirror_output
```
Then open `http://localhost:8000/`.
