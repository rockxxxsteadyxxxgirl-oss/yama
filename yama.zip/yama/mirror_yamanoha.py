"""Simple site mirroring script for https://yamanoha.official.jp/.

Features:
- Crawls internal pages up to a configurable page limit.
- Downloads HTML plus common assets (css/js/images/fonts).
- Rewrites internal links in saved HTML to point at the local copies.

Usage:
    python mirror_yamanoha.py --output output_dir
    python mirror_yamanoha.py --start-url https://example.com --max-pages 30
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from collections import deque
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable, Iterator, Tuple
from urllib.parse import urljoin, urlparse

import requests
import warnings

from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)


DEFAULT_START_URL = "https://yamanoha.official.jp/"
INTERNAL_HOSTS = {"yamanoha.official.jp", "www.yamanoha.official.jp"}
HTML_LIKE_EXTS = {"", ".html", ".htm", ".php", ".asp", ".aspx"}
ASSET_EXTS = {
    ".css",
    ".js",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".svg",
    ".webp",
    ".ico",
    ".woff",
    ".woff2",
    ".ttf",
    ".otf",
    ".eot",
    ".json",
    ".mp4",
    ".webm",
}


@dataclass
class CrawlTarget:
    url: str
    depth: int


def sanitize_path_component(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z._/-]+", "_", text)


def to_local_path(url: str, output_dir: Path) -> Path:
    parsed = urlparse(url)
    path = parsed.path or "/"
    if path.endswith("/"):
        path = f"{path}index.html"
    suffix = PurePosixPath(path).suffix
    if not suffix and not path.endswith(".html"):
        path = f"{path}.html"
    if parsed.query:
        safe_q = re.sub(r"[^0-9A-Za-z._-]+", "_", parsed.query)
        path = f"{path}__{safe_q}"
    path = sanitize_path_component(path.lstrip("/"))
    if parsed.netloc not in INTERNAL_HOSTS:
        path = f"{parsed.netloc}/{path}"
    return output_dir.joinpath(Path(path))


def is_internal(url: str) -> bool:
    return urlparse(url).netloc in INTERNAL_HOSTS


def split_srcset(value: str) -> Iterable[str]:
    for chunk in value.split(","):
        candidate = chunk.strip().split(" ")[0]
        if candidate:
            yield candidate


def collect_links(html: str, base_url: str) -> Tuple[set[str], set[str]]:
    soup = BeautifulSoup(html, "html.parser")
    raw_links: set[str] = set()
    for tag in soup.find_all(True):
        if tag.has_attr("href"):
            raw_links.add(tag["href"])
        if tag.has_attr("src"):
            raw_links.add(tag["src"])
        if tag.has_attr("srcset"):
            raw_links.update(split_srcset(tag["srcset"]))
    resolved = set()
    for link in raw_links:
        if not link or link.startswith("#") or link.startswith("mailto:") or link.startswith("tel:"):
            continue
        abs_url = urljoin(base_url, link)
        parsed = urlparse(abs_url)
        if parsed.scheme not in {"http", "https"}:
            continue
        resolved.add(abs_url)

    page_links: set[str] = set()
    asset_links: set[str] = set()
    for url in resolved:
        parsed = urlparse(url)
        ext = PurePosixPath(parsed.path).suffix.lower()
        if parsed.netloc in INTERNAL_HOSTS and (ext in HTML_LIKE_EXTS or parsed.path.endswith("/")):
            page_links.add(url)
        elif ext in ASSET_EXTS or not ext:
            asset_links.add(url)
    return page_links, asset_links


def rewrite_internal_links(html: str, base_url: str, output_dir: Path, page_path: Path) -> str:
    soup = BeautifulSoup(html, "html.parser")
    attr_names = ("href", "src")

    def maybe_rewrite(url_value: str) -> str:
        abs_url = urljoin(base_url, url_value)
        if not is_internal(abs_url):
            return url_value
        local_target = to_local_path(abs_url, output_dir)
        rel_path = Path(os_relpath(local_target, page_path.parent)).as_posix()
        return rel_path

    for tag in soup.find_all(True):
        for attr in attr_names:
            if tag.has_attr(attr):
                tag[attr] = maybe_rewrite(tag[attr])
        if tag.has_attr("srcset"):
            rewritten = []
            for candidate in split_srcset(tag["srcset"]):
                rel = maybe_rewrite(candidate)
                descriptor = candidate.strip().split(" ")[1:]  # keep descriptors like "2x"
                rewritten.append(" ".join([rel, *descriptor]).strip())
            tag["srcset"] = ", ".join(rewritten)
    return str(soup)


def os_relpath(target: Path, start: Path) -> str:
    return os.path.relpath(target, start).replace("\\", "/")


def download_file(session: requests.Session, url: str, dest: Path, timeout: float) -> str:
    dest.parent.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": "yama-mirror/1.0"}
    with session.get(url, stream=True, timeout=timeout, headers=headers) as resp:
        resp.raise_for_status()
        content_type = resp.headers.get("content-type", "")
        mode = "wb"
        data_chunks = resp.iter_content(chunk_size=16384)
        with open(dest, mode) as fh:
            for chunk in data_chunks:
                if chunk:
                    fh.write(chunk)
    return content_type


def crawl(start_url: str, output_dir: Path, max_pages: int, timeout: float) -> None:
    session = requests.Session()
    queue: deque[CrawlTarget] = deque([CrawlTarget(start_url, 0)])
    visited_pages: set[str] = set()
    downloaded_assets: set[str] = set()
    pages_downloaded = 0

    while queue and pages_downloaded < max_pages:
        current = queue.popleft()
        if current.url in visited_pages:
            continue
        print(f"[page] {current.url}")
        visited_pages.add(current.url)

        page_path = to_local_path(current.url, output_dir)
        page_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            headers = {"User-Agent": "yama-mirror/1.0"}
            resp = session.get(current.url, timeout=timeout, headers=headers)
            resp.raise_for_status()
        except Exception as exc:
            print(f"  ! failed to fetch page: {exc}")
            continue

        html = resp.text
        pages_downloaded += 1

        page_links, asset_links = collect_links(html, current.url)

        rewritten_html = rewrite_internal_links(html, current.url, output_dir, page_path)
        page_path.write_text(rewritten_html, encoding=resp.encoding or "utf-8")

        for asset_url in asset_links:
            if asset_url in downloaded_assets:
                continue
            downloaded_assets.add(asset_url)
            asset_path = to_local_path(asset_url, output_dir)
            print(f"  [asset] {asset_url}")
            try:
                download_file(session, asset_url, asset_path, timeout)
            except Exception as exc:
                print(f"    ! failed to fetch asset: {exc}")

        for link in page_links:
            if link not in visited_pages:
                queue.append(CrawlTarget(link, current.depth + 1))

    print(f"Completed: {pages_downloaded} page(s) mirrored to {output_dir}")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Mirror yamanoha.official.jp into a local folder.")
    parser.add_argument("--start-url", default=DEFAULT_START_URL, help="Root URL to crawl.")
    parser.add_argument(
        "--output",
        default="mirror_output",
        help="Destination directory for mirrored files (will be created).",
    )
    parser.add_argument("--max-pages", type=int, default=20, help="Max number of HTML pages to crawl.")
    parser.add_argument("--timeout", type=float, default=15.0, help="HTTP timeout in seconds.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    output_dir = Path(args.output).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    crawl(args.start_url, output_dir, max_pages=args.max_pages, timeout=args.timeout)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
